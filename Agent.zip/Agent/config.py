import os
from dotenv import load_dotenv
import truststore; truststore.inject_into_ssl(); import httpx
load_dotenv()

HF_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")

HF_LLM_MODEL = os.getenv(
    "HF_LLM_MODEL",
    "HuggingFaceH4/zephyr-7b-beta"
)

HF_EMBEDDING_MODEL = os.getenv(
    "HF_EMBEDDING_MODEL",
    "sentence-transformers/all-MiniLM-L6-v2"
)

KNOWLEDGE_DIR = "knowledge_base"
VECTOR_DIR = "vectorstore/chroma_db"

if not HF_TOKEN:
    raise RuntimeError(
        "HUGGINGFACEHUB_API_TOKEN is missing. "
        "Add it to your .env file."
    )