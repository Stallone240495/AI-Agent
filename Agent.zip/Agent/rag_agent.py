from langchain_chroma import Chroma
import truststore; truststore.inject_into_ssl(); import httpx
from langchain_huggingface import (
    HuggingFaceEmbeddings,
    ChatHuggingFace,
    HuggingFaceEndpoint
)
from langchain_core.prompts import ChatPromptTemplate

import re

from config import (
    HF_TOKEN,
    HF_LLM_MODEL,
    HF_EMBEDDING_MODEL,
    VECTOR_DIR
)


# ============================================================
# EMBEDDINGS
# ============================================================

embeddings = HuggingFaceEmbeddings(
    model_name=HF_EMBEDDING_MODEL,
    model_kwargs={
        "device": "cpu"
    },
    encode_kwargs={
        "normalize_embeddings": True
    }
)


# ============================================================
# CHROMA VECTOR DATABASE
# ============================================================

vectorstore = Chroma(
    collection_name="dance_knowledge",
    persist_directory=VECTOR_DIR,
    embedding_function=embeddings
)


# ============================================================
# RETRIEVER
# ============================================================

retriever = vectorstore.as_retriever(
    search_kwargs={
        "k": 5
    }
)


# ============================================================
# HUGGING FACE MODEL
# ============================================================

llm = HuggingFaceEndpoint(
    repo_id=HF_LLM_MODEL,
    huggingfacehub_api_token=HF_TOKEN,
    task="conversational",
    temperature=0.3,
    max_new_tokens=512
)

chat_model = ChatHuggingFace(
    llm=llm
)


# ============================================================
# PROMPT
# ============================================================

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
You are AIRA a AI Assistant.

Your task is to answer the user's question using ONLY the information
provided in the knowledge base.

STRICT OUTPUT RULES:
- Do not speak or type '*' in the answer.
- Answer or respond ONLY in English
- Pronounce AIRA as AYRA but always write it as AIRA.
- Output ONLY the final answer.
- Do NOT explain how you arrived at the answer.
- Do NOT analyze the question.
- Do NOT repeat or summarize the instructions.
- Do NOT say "We are given", "We note", "According to the rules",
  "Important", or similar reasoning phrases.
- Do NOT mention the knowledge base or retrieved context.
- Do NOT show your reasoning or chain of thought.
- Do NOT output <think> or <thinking> tags.
- Do NOT add information that is not present in the knowledge base.
- Keep the answer concise: 4 to 5 sentences maximum.
- Start directly with the answer.

If the information is not available in the provided context,
respond only with:

"I don't have that information in my knowledge base."

Retrieved information:

{context}
"""
        ),
        (
            "human",
            "{question}"
        )
    ]
)

# ============================================================
# REMOVE MODEL REASONING
# ============================================================

def clean_answer(text: str) -> str:

    if not text:
        return ""

    # Remove complete <think>...</think> blocks
    text = re.sub(
        r"<think>.*?</think>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE
    )

    # Remove complete <thinking>...</thinking> blocks
    text = re.sub(
        r"<thinking>.*?</thinking>",
        "",
        text,
        flags=re.DOTALL | re.IGNORECASE
    )

    # Remove any remaining thinking tags
    text = re.sub(
        r"</?think(?:ing)?>",
        "",
        text,
        flags=re.IGNORECASE
    )

    # Remove leading/trailing whitespace
    return text.strip()


# ============================================================
# ASK AGENT
# ============================================================

def ask_agent(question: str):

    # --------------------------------------------------------
    # Retrieve relevant documents
    # --------------------------------------------------------

    docs = retriever.invoke(question)

    # --------------------------------------------------------
    # Build context
    # --------------------------------------------------------

    context = "\n\n".join(
        doc.page_content
        for doc in docs
    )

    # --------------------------------------------------------
    # Build prompt
    # --------------------------------------------------------

    messages = prompt.format_messages(
        context=context,
        question=question
    )

    # --------------------------------------------------------
    # Call Hugging Face
    # --------------------------------------------------------

    response = chat_model.invoke(messages)

    # ChatHuggingFace returns an AIMessage
    answer = response.content

    # --------------------------------------------------------
    # Remove reasoning
    # --------------------------------------------------------

    answer = clean_answer(answer)

    # --------------------------------------------------------
    # Return answer + sources
    # --------------------------------------------------------

    return {
        "answer": answer,
        "sources": docs
    }