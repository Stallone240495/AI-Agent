import os
import time
import tempfile
import asyncio

import truststore
import edge_tts

from faster_whisper import WhisperModel
from mutagen.mp3 import MP3


# =========================================================
# WINDOWS SSL CERTIFICATE STORE
# =========================================================

# Allows Python libraries to use the Windows certificate
# store. Useful on corporate Windows machines.
truststore.inject_into_ssl()


# =========================================================
# AIRA VOICE CONFIGURATION
# =========================================================

AIRA_VOICE = "en-US-AriaNeural"

# Slightly slower speech sounds clearer and more natural.
AIRA_RATE = "-7%"

AIRA_VOLUME = "+0%"

AIRA_PITCH = "+0Hz"


# =========================================================
# WHISPER MODEL
# =========================================================

_whisper_model = None


def get_whisper_model():
    """
    Load Faster Whisper once and reuse it.
    """

    global _whisper_model

    if _whisper_model is None:

        print("=" * 60)
        print("Loading Whisper model...")
        print("=" * 60)

        try:

            _whisper_model = WhisperModel(
                "base",
                device="cpu",
                compute_type="int8",
            )

            print(
                "Whisper model loaded successfully."
            )

        except Exception as e:

            print()
            print("=" * 60)
            print("WHISPER MODEL ERROR")
            print("=" * 60)

            print(
                type(e).__name__
                + ": "
                + str(e)
            )

            print("=" * 60)

            raise

    return _whisper_model


# =========================================================
# SPEECH TO TEXT
# =========================================================

def speech_to_text(audio_file):
    """
    Convert Streamlit audio input into text using
    Faster Whisper.

    Supports:
        - Streamlit UploadedFile
        - Raw bytes
        - bytearray

    Returns:
        Recognized text.
    """

    if audio_file is None:
        return ""

    temp_path = None

    try:

        # -------------------------------------------------
        # GET AUDIO BYTES
        # -------------------------------------------------

        if hasattr(
            audio_file,
            "getvalue",
        ):

            audio_bytes = (
                audio_file.getvalue()
            )

        elif isinstance(
            audio_file,
            (bytes, bytearray),
        ):

            audio_bytes = audio_file

        else:

            raise TypeError(
                "Unsupported audio input type: "
                f"{type(audio_file)}"
            )

        # -------------------------------------------------
        # CHECK AUDIO
        # -------------------------------------------------

        if not audio_bytes:

            print(
                "No audio data received."
            )

            return ""

        # -------------------------------------------------
        # CREATE TEMPORARY WAV
        # -------------------------------------------------

        with tempfile.NamedTemporaryFile(
            suffix=".wav",
            delete=False,
        ) as temp_file:

            temp_file.write(
                audio_bytes
            )

            temp_path = (
                temp_file.name
            )

        print()
        print("=" * 60)
        print("AUDIO RECEIVED")
        print("=" * 60)

        print(
            "Temporary recording:",
            temp_path,
        )

        # -------------------------------------------------
        # LOAD WHISPER
        # -------------------------------------------------

        model = (
            get_whisper_model()
        )

        # -------------------------------------------------
        # TRANSCRIBE
        # -------------------------------------------------

        print()
        print("=" * 60)
        print("TRANSCRIBING AUDIO")
        print("=" * 60)

        segments, info = model.transcribe(
        temp_path,
        language="en",
        task="transcribe",
        beam_size=5,
        vad_filter=True,
        )
        # Faster Whisper returns a generator.
        text_parts = []

        for segment in segments:

            segment_text = (
                segment.text.strip()
            )

            if segment_text:

                text_parts.append(
                    segment_text
                )

        text = " ".join(
            text_parts
        ).strip()

        print(
            "Recognized speech:",
            text,
        )

        print("=" * 60)

        return text

    except Exception as e:

        print()
        print("=" * 60)
        print("SPEECH TO TEXT ERROR")
        print("=" * 60)

        print(
            type(e).__name__
            + ": "
            + str(e)
        )

        print("=" * 60)

        return ""

    finally:

        # -------------------------------------------------
        # DELETE TEMP MICROPHONE RECORDING
        # -------------------------------------------------

        if (
            temp_path
            and os.path.exists(
                temp_path
            )
        ):

            try:

                os.remove(
                    temp_path
                )

            except Exception as cleanup_error:

                print(
                    "Could not delete "
                    "temporary recording:",
                    cleanup_error,
                )


# =========================================================
# EDGE TTS GENERATOR
# =========================================================

async def _generate_edge_speech(
    text,
    output_path,
):
    """
    Generate speech using Microsoft Edge TTS.
    """

    communicate = (
        edge_tts.Communicate(
            text=str(text),
            voice=AIRA_VOICE,
            rate=AIRA_RATE,
            volume=AIRA_VOLUME,
            pitch=AIRA_PITCH,
        )
    )

    await communicate.save(
        output_path
    )


# =========================================================
# TEXT TO SPEECH
# =========================================================

def text_to_speech(text):
    """
    Convert text to speech using Microsoft Edge TTS.

    Voice:
        en-US-AriaNeural

    Returns:
        Path to generated MP3.

    Returns None if generation fails.
    """

    if text is None:
        return None

    text = str(text).strip()

    if not text:
        return None

    mp3_path = None

    try:

        # -------------------------------------------------
        # CREATE UNIQUE MP3 PATH
        # -------------------------------------------------

        temp_directory = (
            tempfile.gettempdir()
        )

        filename = (
            f"aira_"
            f"{os.getpid()}_"
            f"{time.time_ns()}.mp3"
        )

        mp3_path = os.path.join(
            temp_directory,
            filename,
        )

        # -------------------------------------------------
        # LOG
        # -------------------------------------------------

        print()
        print("=" * 60)
        print("GENERATING AIRA VOICE")
        print("=" * 60)

        print(
            "Voice:",
            AIRA_VOICE,
        )

        print(
            "Rate:",
            AIRA_RATE,
        )

        print(
            "Volume:",
            AIRA_VOLUME,
        )

        print(
            "Pitch:",
            AIRA_PITCH,
        )

        print(
            "Output:",
            mp3_path,
        )

        # -------------------------------------------------
        # GENERATE EDGE TTS AUDIO
        # -------------------------------------------------

        asyncio.run(
            _generate_edge_speech(
                text,
                mp3_path,
            )
        )

        # -------------------------------------------------
        # CHECK FILE EXISTS
        # -------------------------------------------------

        if not os.path.isfile(
            mp3_path
        ):

            raise RuntimeError(
                "Edge TTS did not create "
                "the MP3 file."
            )

        # -------------------------------------------------
        # CHECK FILE SIZE
        # -------------------------------------------------

        file_size = (
            os.path.getsize(
                mp3_path
            )
        )

        if file_size < 100:

            raise RuntimeError(
                "Edge TTS generated an "
                "invalid MP3 file. "
                f"File size: {file_size} bytes."
            )

        print(
            "Generated MP3 size:",
            file_size,
            "bytes",
        )

        print(
            "Aira voice generated "
            "successfully."
        )

        print("=" * 60)

        return mp3_path

    except Exception as e:

        print()
        print("=" * 60)
        print("TEXT TO SPEECH ERROR")
        print("=" * 60)

        print(
            type(e).__name__
            + ": "
            + str(e)
        )

        print("=" * 60)

        # -------------------------------------------------
        # DELETE FAILED AUDIO
        # -------------------------------------------------

        if (
            mp3_path
            and os.path.exists(
                mp3_path
            )
        ):

            try:

                os.remove(
                    mp3_path
                )

            except Exception:
                pass

        return None


# =========================================================
# AUDIO DURATION
# =========================================================

def get_audio_duration(audio_path):
    """
    Return MP3 audio duration in seconds.

    Uses Mutagen instead of ffprobe.

    Returns:
        Duration in seconds.

    Returns 0 if duration cannot be calculated.
    """

    if not audio_path:
        return 0

    if not os.path.isfile(
        audio_path
    ):
        return 0

    try:

        audio = MP3(
            audio_path
        )

        duration = float(
            audio.info.length
        )

        print(
            "Audio duration:",
            round(
                duration,
                2,
            ),
            "seconds",
        )

        return duration

    except Exception as e:

        print(
            "Could not calculate "
            "audio duration:",
            e,
        )

        return 0


# =========================================================
# DELETE GENERATED AUDIO
# =========================================================

def cleanup_audio(audio_path):
    """
    Delete generated temporary Aira MP3.
    """

    if not audio_path:
        return

    if not os.path.isfile(
        audio_path
    ):
        return

    try:

        os.remove(
            audio_path
        )

        print(
            "Deleted temporary audio:",
            audio_path,
        )

    except Exception as e:

        print(
            "Could not delete "
            "temporary audio:",
            e,
        )