# 🤖 AIRA – AI RAG Voice & Text Assistant

AIRA is an AI-powered **Retrieval-Augmented Generation (RAG) Assistant** that allows users to interact using both **text and voice**.

AIRA retrieves relevant information from a local knowledge base using semantic search and uses a Hugging Face Large Language Model to generate context-aware responses.

The application is built using:

- Python
- Streamlit
- LangChain
- Hugging Face
- Sentence Transformers
- ChromaDB
- Faster Whisper

---

# ✨ Features

AIRA provides the following capabilities:

- ⌨️ Text-based user input
- 🎤 Microphone-based voice input
- 📝 Speech-to-text transcription
- 🗣️ AI response audio playback
- 📚 Retrieval-Augmented Generation (RAG)
- 📄 PDF/document knowledge-base ingestion
- 🔎 Semantic similarity search
- 🧠 Hugging Face LLM integration
- 🧬 Sentence Transformer embeddings
- 💾 Persistent ChromaDB vector database
- 💬 Interactive Streamlit interface
- 🎨 Custom AIRA branding
- 🖼️ Custom application background
- 🔐 Environment-variable based configuration
- ♻️ Reusable local vector store

---

# 🏗️ Architecture

AIRA supports two ways of asking questions:

1. **Text Input**
2. **Voice Input**

Both inputs eventually use the same RAG pipeline.

```text
                         ┌──────────────────────┐
                         │         USER         │
                         └──────────┬───────────┘
                                    │
                      ┌─────────────┴─────────────┐
                      │                           │
                      ▼                           ▼
             ┌─────────────────┐        ┌─────────────────┐
             │   TEXT INPUT    │        │   VOICE INPUT   │
             │    Streamlit    │        │   Microphone    │
             └────────┬────────┘        └────────┬────────┘
                      │                          │
                      │                          ▼
                      │                 ┌─────────────────┐
                      │                 │ Faster Whisper  │
                      │                 │ Speech-to-Text  │
                      │                 └────────┬────────┘
                      │                          │
                      └────────────┬─────────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │     RAG AGENT      │
                         │   rag_agent.py     │
                         └─────────┬──────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │ Question Embedding │
                         └─────────┬──────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │      ChromaDB      │
                         │   Vector Search    │
                         └─────────┬──────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │ Relevant Knowledge │
                         │       Chunks       │
                         └─────────┬──────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │  Hugging Face LLM  │
                         └─────────┬──────────┘
                                   │
                                   ▼
                         ┌────────────────────┐
                         │    AI RESPONSE     │
                         └─────────┬──────────┘
                                   │
                      ┌────────────┴────────────┐
                      │                         │
                      ▼                         ▼
             ┌─────────────────┐       ┌─────────────────┐
             │  TEXT RESPONSE  │       │ AUDIO RESPONSE  │
             │    Streamlit    │       │      TTS        │
             └─────────────────┘       └─────────────────┘
```

---

# 📁 Project Structure

The project structure is:

```text
AiraAgent/
│
├── assets/
│   ├── Background.png
│   └── Logo.png
│
├── knowledge_base/
│   └── knowledge_base.pdf
│
├── vectorstore/
│   └── ChromaDB vector data
│
├── venv/
│
├── .env
├── app.py
├── config.py
├── ingest.py
├── rag_agent.py
├── voice.py
├── requirements.txt
└── ReadMe.md
```

---

# 📄 File Responsibilities

| File / Folder | Description |
|---|---|
| `app.py` | Main Streamlit application and UI |
| `config.py` | Application and model configuration |
| `ingest.py` | Loads, chunks and embeds knowledge-base documents |
| `rag_agent.py` | Handles document retrieval and LLM interaction |
| `voice.py` | Handles speech/voice functionality |
| `.env` | Environment variables and API credentials |
| `requirements.txt` | Python dependencies |
| `knowledge_base/` | Documents used by the RAG system |
| `vectorstore/` | Persistent ChromaDB vector database |
| `assets/` | AIRA logo and background images |
| `venv/` | Python virtual environment |

---

# 🧠 How AIRA Works

AIRA uses **Retrieval-Augmented Generation (RAG)**.

Instead of sending a question directly to the LLM and relying entirely on its existing knowledge, AIRA first searches the local knowledge base for relevant information.

The retrieved information is then provided to the LLM as context.

```text
User Question
      │
      ▼
Question Embedding
      │
      ▼
ChromaDB
      │
      ▼
Semantic Search
      │
      ▼
Relevant Document Chunks
      │
      ▼
Context + User Question
      │
      ▼
Hugging Face LLM
      │
      ▼
AIRA Response
```

This allows AIRA to answer questions based on information stored in the supplied knowledge base.

---

# 🧬 Embedding Model

AIRA uses:

```text
sentence-transformers/all-MiniLM-L6-v2
```

The embedding model converts text into numerical vector representations.

For example:

```text
"What is the hackathon theme?"
            ↓
Embedding Model
            ↓
[0.12, -0.41, 0.73, ...]
```

Document chunks are also converted into vectors.

ChromaDB compares these vectors to determine which knowledge-base content is most relevant to the user's question.

---

# 🧠 Large Language Model

The configured Hugging Face LLM is:

```text
meta-llama/Llama-3.1-8B-Instruct
```

The model receives:

```text
User Question
       +
Retrieved Knowledge Base Context
       ↓
Hugging Face LLM
       ↓
Generated Response
```

The model can be changed through the `.env` configuration.

---

# 💾 Vector Database

AIRA uses **ChromaDB** as the vector database.

The generated vectors are stored locally inside:

```text
vectorstore/
```

This allows the application to reuse previously generated embeddings instead of embedding all documents every time the application starts.

---

# 🎤 Voice Processing

AIRA supports microphone-based questions.

The voice workflow is:

```text
User speaks
     ↓
Microphone
     ↓
Audio recording
     ↓
voice.py
     ↓
Faster Whisper
     ↓
Speech-to-Text
     ↓
Transcribed Question
     ↓
RAG Agent
     ↓
AIRA Response
```

**Faster Whisper is used for speech-to-text transcription.**

If `voice.py` also provides text-to-speech functionality, the generated response can additionally be played back to the user as audio.

---

# ⌨️ Text Processing

Users can also type questions directly into AIRA.

For example:

```text
What is the theme of the hackathon?
```

The workflow becomes:

```text
Text Input
     ↓
rag_agent.py
     ↓
ChromaDB Search
     ↓
Relevant Context
     ↓
Hugging Face LLM
     ↓
AIRA Response
```

Voice and text therefore use the **same RAG pipeline** after the user question has been converted into text.

---

# 🚀 Installation and Setup

## 1. Prerequisites

Before running AIRA, make sure you have:

- Python 3.10 or newer
- pip
- Git
- Hugging Face account
- Hugging Face API token
- Microphone access for voice input

Check Python:

```bash
python3 --version
```

Check pip:

```bash
pip3 --version
```

Check Git:

```bash
git --version
```

---

# 2. Open the Project

Navigate to the project directory:

```bash
cd AiraAgent
```

---

# 3. Create a Virtual Environment

Using a virtual environment prevents project dependencies from interfering with other Python applications.

## macOS / Linux

Create the environment:

```bash
python3 -m venv venv
```

Activate it:

```bash
source venv/bin/activate
```

## Windows

Create the environment:

```bash
python -m venv venv
```

Activate it:

```bash
venv\Scripts\activate
```

After activation, the terminal should display something similar to:

```text
(venv)
```

---

# 4. Upgrade pip

Run:

```bash
python -m pip install --upgrade pip
```

---

# 5. Install Dependencies

Install all project dependencies:

```bash
pip install -r requirements.txt
```

The `requirements.txt` contains:

```txt
streamlit
python-dotenv

# LangChain
langchain
langchain-community
langchain-text-splitters
langchain-huggingface
langchain-chroma

# Hugging Face
huggingface-hub
transformers
sentence-transformers
torch

# Vector database
chromadb

# Document loaders
pypdf
python-docx
docx2txt

# Speech-to-text
faster-whisper
```

---

# 🔐 6. Configure Environment Variables

Create a `.env` file in the root directory.

```text
AiraAgent/
│
├── .env
├── app.py
├── config.py
└── ...
```

Add:

```env
HUGGINGFACEHUB_API_TOKEN=your_huggingface_token

HF_LLM_MODEL=meta-llama/Llama-3.1-8B-Instruct

HF_EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
```

Replace:

```text
your_huggingface_token
```

with your actual Hugging Face token.

For example:

```env
HUGGINGFACEHUB_API_TOKEN=hf_xxxxxxxxxxxxxxxxx
```

> ⚠️ Never share or commit your real Hugging Face API token.

---

# 🔑 Hugging Face Model Access

Some Hugging Face models are gated.

If you are using:

```text
meta-llama/Llama-3.1-8B-Instruct
```

make sure the Hugging Face account associated with your API token has access to that model.

Otherwise, model requests may return authorization or access errors.

---

# 📚 7. Add the Knowledge Base

Place the documents that AIRA should use inside:

```text
knowledge_base/
```

For example:

```text
knowledge_base/
│
└── knowledge_base.pdf
```

The documents in this folder provide the information used by the RAG system.

---

# 🧬 8. Build the Vector Store

Before running AIRA for the first time, the documents must be converted into embeddings.

Run:

```bash
python ingest.py
```

On systems where the Python command is `python3`:

```bash
python3 ingest.py
```

The ingestion process is:

```text
knowledge_base/
       ↓
Document Loader
       ↓
Text Extraction
       ↓
Text Splitter
       ↓
Document Chunks
       ↓
Hugging Face Embeddings
       ↓
ChromaDB
       ↓
vectorstore/
```

After successful ingestion, ChromaDB data should exist inside:

```text
vectorstore/
```

---

# ▶️ 9. Run AIRA

Start the Streamlit application:

```bash
streamlit run app.py
```

If the `streamlit` command is unavailable, run:

```bash
python -m streamlit run app.py
```

Streamlit should display something similar to:

```text
You can now view your Streamlit app in your browser.

Local URL: http://localhost:8501
```

Open the displayed Local URL in your browser.

AIRA is now ready.

---

# ⚡ Quick Start

After the project has already been configured, starting AIRA only requires a few commands.

## macOS / Linux

```bash
cd AiraAgent
source venv/bin/activate
streamlit run app.py
```

## Windows

```bash
cd AiraAgent
venv\Scripts\activate
streamlit run app.py
```

---

# 💬 Using AIRA

AIRA supports both:

```text
⌨️ Text Input
🎤 Voice Input
```

---

## ⌨️ Text Input

Type a question into the AIRA text field.

Example:

```text
What is the theme of the hackathon?
```

Press Enter or submit the question.

AIRA will:

1. Convert the question into an embedding.
2. Search ChromaDB.
3. Retrieve relevant knowledge-base content.
4. Send the retrieved context and question to the LLM.
5. Generate a response.
6. Display the response in the application.

---

## 🎤 Voice Input

Use the microphone/record control in the application.

Speak your question.

Example:

```text
Who is the guest visiting from ING Australia?
```

AIRA will:

1. Capture the microphone audio.
2. Send the audio to the speech-to-text pipeline.
3. Transcribe the audio using Faster Whisper.
4. Send the transcribed question to the RAG agent.
5. Search ChromaDB.
6. Retrieve relevant context.
7. Generate the answer using the LLM.
8. Display the response.
9. Play the response as audio if text-to-speech is enabled.

---

# 🧪 Example Questions

Depending on the current knowledge base, example questions include:

```text
What is the theme of the hackathon?
```

```text
Who is the guest visiting from ING Australia?
```

```text
Who can participate in the hackathon?
```

```text
What are the participation rules?
```

```text
Who should I contact for more information?
```

The same questions can be either **typed or spoken**.

---

# 🔄 Updating the Knowledge Base

When documents are added or modified inside:

```text
knowledge_base/
```

the vector store should be regenerated.

Stop the Streamlit application:

```text
Ctrl + C
```

Run:

```bash
python ingest.py
```

Then restart AIRA:

```bash
streamlit run app.py
```

The updated information will now be available to the RAG system.

---

# 🔁 Normal Development Workflow

You do **not** need to reinstall dependencies every time you start AIRA.

For normal development:

```bash
cd AiraAgent
```

Activate the environment:

```bash
source venv/bin/activate
```

Then:

```bash
streamlit run app.py
```

---

# 🔄 When Code Changes

If you modify:

```text
app.py
rag_agent.py
voice.py
config.py
```

you normally only need to restart or rerun Streamlit.

```bash
streamlit run app.py
```

---

# 📚 When Knowledge Changes

If you modify:

```text
knowledge_base/
```

run:

```bash
python ingest.py
```

Then:

```bash
streamlit run app.py
```

---

# 📦 When Requirements Change

If `requirements.txt` changes, run:

```bash
pip install -r requirements.txt
```

---

# 🛑 Stop AIRA

Go to the terminal where Streamlit is running and press:

```text
Ctrl + C
```

This stops the local Streamlit server.

---

# 🛠️ Troubleshooting

## `streamlit: command not found`

Make sure the virtual environment is activated:

```bash
source venv/bin/activate
```

Then install dependencies:

```bash
pip install -r requirements.txt
```

Alternatively:

```bash
python -m streamlit run app.py
```

---

## `ModuleNotFoundError`

Example:

```text
ModuleNotFoundError: No module named 'langchain'
```

Activate the virtual environment and reinstall dependencies:

```bash
source venv/bin/activate
pip install -r requirements.txt
```

---

## Hugging Face Authentication Error

Verify that `.env` contains:

```env
HUGGINGFACEHUB_API_TOKEN=your_valid_token
```

After modifying `.env`, restart Streamlit.

---

## Hugging Face Model Access Error

Some models require explicit account access.

Verify that your Hugging Face account has access to:

```text
meta-llama/Llama-3.1-8B-Instruct
```

Also verify that the token belongs to the account with model access.

---

## Vector Store Not Found

If the application cannot find the vector database, run:

```bash
python ingest.py
```

Verify that:

```text
vectorstore/
```

has been created.

Then run:

```bash
streamlit run app.py
```

---

## Microphone Not Working

Check that:

- Browser microphone permission is enabled.
- The correct microphone is selected.
- The operating system allows microphone access.
- `faster-whisper` is installed.
- The virtual environment is activated.

Reinstall Faster Whisper if necessary:

```bash
pip install faster-whisper
```

---

## PDF Cannot Be Read

Make sure:

```text
pypdf
```

is installed.

Run:

```bash
pip install pypdf
```

Then rebuild the vector store:

```bash
python ingest.py
```

---

## Changes to the PDF Are Not Reflected

Changing the source document does not automatically update existing embeddings.

Run:

```bash
python ingest.py
```

Then restart:

```bash
streamlit run app.py
```

---

# 🔐 Security

API tokens and credentials should never be stored directly inside Python files.

Store secrets inside:

```text
.env
```

For example:

```env
HUGGINGFACEHUB_API_TOKEN=your_token
```

Never commit the `.env` file to source control.

---

# 🚫 Recommended `.gitignore`

Create a `.gitignore` file in the project root:

```gitignore
# Environment variables / secrets
.env

# Virtual environments
venv/
.venv/

# Python cache
__pycache__/
*.py[cod]
*$py.class

# macOS
.DS_Store

# VS Code
.vscode/

# PyCharm
.idea/
```

If you want each environment to generate its own ChromaDB vector store, also add:

```gitignore
vectorstore/
```

---

# ⚠️ API Token Security

Never:

- Upload `.env` to GitHub.
- Upload `.env` to Azure DevOps.
- Include tokens in screenshots.
- Hard-code tokens inside Python files.
- Share API tokens with other users.

If a token is accidentally exposed, revoke it and generate a new one.

---

# 📊 Technology Stack

| Technology | Purpose |
|---|---|
| Python | Core programming language |
| Streamlit | User interface |
| LangChain | RAG orchestration |
| Hugging Face | LLM/model integration |
| Transformers | Model tooling |
| Sentence Transformers | Embedding generation |
| ChromaDB | Vector database |
| Faster Whisper | Speech-to-text |
| PyPDF | PDF document loading |
| python-docx | Word document support |
| docx2txt | Word text extraction |
| python-dotenv | Environment configuration |

---

# 📦 Python Dependencies

```text
streamlit
python-dotenv
langchain
langchain-community
langchain-text-splitters
langchain-huggingface
langchain-chroma
huggingface-hub
transformers
sentence-transformers
torch
chromadb
pypdf
python-docx
docx2txt
faster-whisper
```

---

# 🔄 Complete First-Time Setup Flow

```text
Clone / Open AiraAgent
          │
          ▼
Create Virtual Environment
          │
          ▼
Activate Virtual Environment
          │
          ▼
Install requirements.txt
          │
          ▼
Configure .env
          │
          ▼
Add Documents to knowledge_base/
          │
          ▼
Run ingest.py
          │
          ▼
Generate Embeddings
          │
          ▼
Store in ChromaDB
          │
          ▼
Run streamlit app.py
          │
          ▼
       AIRA
          │
     ┌────┴────┐
     ▼         ▼
   Text       Voice
   Input      Input
     │         │
     └────┬────┘
          ▼
      RAG Agent
          │
          ▼
      ChromaDB
          │
          ▼
   Hugging Face LLM
          │
          ▼
    AIRA Response
```

---

# ⚡ Commands Summary

## First-Time Setup – macOS / Linux

```bash
cd AiraAgent

python3 -m venv venv

source venv/bin/activate

python -m pip install --upgrade pip

pip install -r requirements.txt

python ingest.py

streamlit run app.py
```

---

## First-Time Setup – Windows

```bash
cd AiraAgent

python -m venv venv

venv\Scripts\activate

python -m pip install --upgrade pip

pip install -r requirements.txt

python ingest.py

streamlit run app.py
```

---

## Normal Startup – macOS / Linux

```bash
cd AiraAgent
source venv/bin/activate
streamlit run app.py
```

---

## Normal Startup – Windows

```bash
cd AiraAgent
venv\Scripts\activate
streamlit run app.py
```

---

## After Updating the Knowledge Base

```bash
python ingest.py
streamlit run app.py
```

---

# 🎯 AIRA

**AIRA – AI RAG Voice & Text Assistant**

AIRA combines:

```text
⌨️ Text Input
      +
🎤 Voice Input
      +
📚 Retrieval-Augmented Generation
      +
🔎 Semantic Search
      +
💾 ChromaDB
      +
🧬 Sentence Transformers
      +
🧠 Hugging Face LLM
      +
💬 Streamlit
```

to provide an interactive AI assistant capable of answering questions using information retrieved from a custom knowledge base.