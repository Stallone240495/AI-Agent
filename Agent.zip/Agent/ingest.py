import os
import truststore; truststore.inject_into_ssl(); import httpx
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    Docx2txtLoader
)

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

from config import (
    KNOWLEDGE_DIR,
    VECTOR_DIR,
    HF_EMBEDDING_MODEL
)


def load_documents():

    documents = []

    if not os.path.exists(KNOWLEDGE_DIR):
        print(f"Knowledge directory not found: {KNOWLEDGE_DIR}")
        return documents

    for filename in os.listdir(KNOWLEDGE_DIR):

        path = os.path.join(KNOWLEDGE_DIR, filename)

        try:

            if filename.lower().endswith(".pdf"):
                loader = PyPDFLoader(path)

            elif filename.lower().endswith(".txt"):
                loader = TextLoader(
                    path,
                    encoding="utf-8"
                )

            elif filename.lower().endswith(".docx"):
                loader = Docx2txtLoader(path)

            else:
                continue

            docs = loader.load()
            documents.extend(docs)

            print(f"Loaded: {filename}")

        except Exception as e:
            print(f"Failed to load {filename}: {e}")

    return documents


def main():

    print("Loading knowledge base...")

    documents = load_documents()

    if not documents:
        print("No documents found.")
        return

    print(f"Documents loaded: {len(documents)}")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_documents(documents)

    print(f"Created {len(chunks)} chunks.")

    print("Creating Hugging Face embeddings...")

    embeddings = HuggingFaceEmbeddings(
        model_name=HF_EMBEDDING_MODEL,
        model_kwargs={
            "device": "cpu"
        },
        encode_kwargs={
            "normalize_embeddings": True
        }
    )

    print("Creating Chroma vector database...")

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name="dance_knowledge",
        persist_directory=VECTOR_DIR
    )

    print("================================")
    print("RAG INGESTION COMPLETE")
    print("================================")
    print(f"Documents : {len(documents)}")
    print(f"Chunks    : {len(chunks)}")
    print(f"Vector DB : {VECTOR_DIR}")


if __name__ == "__main__":
    main()